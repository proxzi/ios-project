//
//  MainInteractor.swift
//  uTravel
//
//  Created by Dmitry on 26.04.2021.
//  
//

import Foundation

final class MainInteractor {
	weak var output: MainInteractorOutput?
}

extension MainInteractor: MainInteractorInput {
}
