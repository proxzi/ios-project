//
//  MainRouter.swift
//  uTravel
//
//  Created by Dmitry on 26.04.2021.
//  
//

import UIKit

final class MainRouter {
}

extension MainRouter: MainRouterInput {
}
