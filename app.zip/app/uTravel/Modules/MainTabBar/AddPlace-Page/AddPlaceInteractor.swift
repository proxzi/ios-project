//
//  AddPlaceInteractor.swift
//  uTravel
//
//  Created by Dmitry on 03.05.2021.
//  
//

import Foundation

final class AddPlaceInteractor {
	weak var output: AddPlaceInteractorOutput?
}

extension AddPlaceInteractor: AddPlaceInteractorInput {
}
