//
//  NotificationRouter.swift
//  uTravel
//
//  Created by Dmitry on 03.05.2021.
//  
//

import UIKit

final class NotificationRouter {
}

extension NotificationRouter: NotificationRouterInput {
}
