//
//  TravelDetailRouter.swift
//  uTravel
//
//  Created by Dmitry on 27.04.2021.
//  
//

import UIKit

final class TravelDetailRouter {
}

extension TravelDetailRouter: TravelDetailRouterInput {
}
