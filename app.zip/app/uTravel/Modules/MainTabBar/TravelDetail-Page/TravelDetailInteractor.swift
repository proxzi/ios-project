//
//  TravelDetailInteractor.swift
//  uTravel
//
//  Created by Dmitry on 27.04.2021.
//  
//

import Foundation

final class TravelDetailInteractor {
	weak var output: TravelDetailInteractorOutput?
}

extension TravelDetailInteractor: TravelDetailInteractorInput {
}
