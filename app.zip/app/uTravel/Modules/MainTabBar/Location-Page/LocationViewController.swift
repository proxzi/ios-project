//
//  LocationViewController.swift
//  uTravel
//
//  Created by Dmitry on 28.05.2021.
//  
//

import UIKit

final class LocationViewController: UIViewController {
	private let output: LocationViewOutput
    
    init(output: LocationViewOutput) {
        self.output = output

        super.init(nibName: nil, bundle: nil)
    }

    @available(*, unavailable)
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

	override func viewDidLoad() {
		super.viewDidLoad()
        view.backgroundColor = .white
	}

    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
    }
    
}

extension LocationViewController: LocationViewInput {
}
