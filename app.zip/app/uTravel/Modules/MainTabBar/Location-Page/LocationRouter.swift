//
//  LocationRouter.swift
//  uTravel
//
//  Created by Dmitry on 28.05.2021.
//  
//

import UIKit

final class LocationRouter {
}

extension LocationRouter: LocationRouterInput {
}
