//
//  AddTravelInteractor.swift
//  uTravel
//
//  Created by Dmitry on 26.04.2021.
//  
//

import UIKit
import Firebase
import FirebaseDatabase

final class AddTravelInteractor {
	weak var output: AddTravelInteractorOutput?
    
    private let imageLoader: ImageLoaderDescription = ImageLoader.shared
    
    private var imageString: String?
    
    private var user: User!
    private var ref: DatabaseReference!
    private var trips = Array<Trip>()
}

extension AddTravelInteractor: AddTravelInteractorInput {
    func saveTrip(trip: Trip) {
        
        imageUpload(with: trip.image, title: "myimage")
        sleep(10)
        ref = Database.database().reference(withPath: "users").child(String(trip.userId)).child("trips")
        let tripRef = self.ref.child(trip.title.lowercased())
        tripRef.setValue(trip.convertToDictionary(img: imageString ?? "nil"))
    }
    
    func imageUpload(with image: UIImage, title: String){
        imageLoader.upload(image: image) { [weak self] (result) in
            switch result {
            case .success(let name):
                self?.output?.didReceiveImage(toString: name)
                self?.imageString = name
            case .failure(let error):
                self?.output?.didReceive(error: error)
            }
        }
    }
    
}
