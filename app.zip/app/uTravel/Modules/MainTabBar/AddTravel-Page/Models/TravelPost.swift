//
//  TravelsModelHelper.swift
//  uTravel
//
//  Created by Dmitry on 04.05.2021.
//

//import UIKit
//
//struct Place {
//    let title: String
//    let image: UIImage
//    let rating: Int
//    let description: String
//    let classPlace: String
//}
//
//struct Travel {
//    let title: String
//    let image: UIImage
//    let location: String
//    let season: String
//    let date: String
//    let price: String
//    let places: [Place]
//}
//
//struct User {
//    let identifier: String
//    let email: String
//    let travels: [Travel]
//}
//
//struct NewUser {
//    let email: String
//    let travels: [Travel]
//}
