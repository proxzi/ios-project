//
//  ProfileProtocols.swift
//  uTravel
//
//  Created by Dmitry on 26.04.2021.
//  
//

import Foundation

protocol ProfileModuleInput {
	var moduleOutput: ProfileModuleOutput? { get }
}

protocol ProfileModuleOutput: class {
}

protocol ProfileViewInput: class {
}

protocol ProfileViewOutput: class {
    func didTapSettingsButton()
    func didSelectItemCollection()
    func didLoadTravels()
}

protocol ProfileInteractorInput: class {
    func updateListTravels()
}

protocol ProfileInteractorOutput: class {
}

protocol ProfileRouterInput: class {
    func openProfileSettings()
    func openTravelDetail()
}
