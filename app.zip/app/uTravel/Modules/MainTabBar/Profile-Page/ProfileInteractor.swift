//
//  ProfileInteractor.swift
//  uTravel
//
//  Created by Dmitry on 26.04.2021.
//  
//

import Foundation

final class ProfileInteractor {
	weak var output: ProfileInteractorOutput?
}

extension ProfileInteractor: ProfileInteractorInput {
    func updateListTravels() {
        
    }
}
