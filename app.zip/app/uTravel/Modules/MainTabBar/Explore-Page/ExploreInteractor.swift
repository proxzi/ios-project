//
//  ExploreInteractor.swift
//  uTravel
//
//  Created by Dmitry on 26.04.2021.
//  
//

import Foundation

final class ExploreInteractor {
	weak var output: ExploreInteractorOutput?
}

extension ExploreInteractor: ExploreInteractorInput {
}
