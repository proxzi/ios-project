//
//  Trip.swift
//  uTravel
//
//  Created by Dmitry on 01.06.2021.
//

import Foundation
import FirebaseDatabase
import UIKit

struct Trip {
    let title: String
    let image: UIImage
    let location: String
    let season: String
    let date: String
    let price: String
    let userId: String
    let ref: FirebaseDatabase.DatabaseReference?
    
    init(title: String, image: UIImage, location: String, season: String, date: String, price: String, userId: String){
        self.title = title
        self.image = image
        self.location = location
        self.season = season
        self.date = date
        self.price = price
        self.userId = userId
        self.ref = nil
    }
    
    init(snapshot: FirebaseDatabase.DataSnapshot) {
        let snapshotValue = snapshot.value as! [String: AnyObject]
        title = snapshotValue["title"] as! String
        image = snapshotValue["image"] as! UIImage
        location = snapshotValue["location"] as! String
        season = snapshotValue["season"] as! String
        date = snapshotValue["date"] as! String
        price = snapshotValue["price"] as! String
        userId = snapshotValue["id"] as! String
        ref = snapshot.ref
    }
    
    func convertToDictionary(img: String) -> Any {
        return ["title": title, "image": img, "location": location, "season": season, "date": date, "price": price, "userId": userId]
    }
}
