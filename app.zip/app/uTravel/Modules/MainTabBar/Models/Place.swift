//
//  Place.swift
//  uTravel
//
//  Created by Dmitry on 01.06.2021.
//

import Foundation
import FirebaseDatabase
import UIKit

struct Place {
    let id: Int
    let title: String
    let image: UIImage
    let rating: Int
    let description: String
    let classPlace: String
    let userId: String
    let ref: FirebaseDatabase.DatabaseReference?
    
    init(place: Place){
        self.id = place.id
        self.title = place.title
        self.image = place.image
        self.rating = place.rating
        self.description = place.description
        self.classPlace = place.classPlace
        self.userId = place.userId
        self.ref = nil
    }
    
    init(snapshot: FirebaseDatabase.DataSnapshot) {
        let snapshotValue = snapshot.value as! [String: AnyObject]
        id = snapshotValue["id"] as! Int
        title = snapshotValue["title"] as! String
        image = snapshotValue["image"] as! UIImage
        rating = snapshotValue["rating"] as! Int
        description = snapshotValue["description"] as! String
        classPlace = snapshotValue["classPlace"] as! String
        userId = snapshotValue["userId"] as! String
        ref = snapshot.ref
    }
    
}
